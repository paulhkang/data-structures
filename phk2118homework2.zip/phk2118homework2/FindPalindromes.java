import java.util.*;
import java.io.*;



public class FindPalindromes extends MyStack
{
	public static int testPerLine(char[] c, char[] newStr, int start)			// creates new char[] newStr that contains only one line of c (huge char[])
	{											// tests newStr to see if it is a palindrome, then loops to test next line
		if(start > 1145)								// continues until end of c
			return 0;




		for(int i = 0; i < newStr.length; i++)						// clear newStr of its values
		{
			newStr[i] = 0;
		}


		
		int newStart = 0;								// clear newStart of its value

		for(int i = start; i < 100; i++)						// fill in newStr with values from one line of c (the huge char[]) 
		{
			if(c[i] != ' ' && c[i] != '.' && c[i] != '\'' && c[i] != ',' && c[i] != '?' && c[i] != '!' && c[i] != ':' && c[i] != '\"' &&
			   c[i] != ';' && c[i] != '-')						// don't fill in newStr with whitespace or punctuation
			{

				if(c[i] == '\n')						// stop filling in values when you encounter a newline
				{
					newStart = i + 1;					// set up newStart variable as starting point for next recursive loop
					break;
				}

				newStr[i] = c[i];
			}
		}


		boolean pal = palTest(newStr);							// test newStr to see if it is a palindrome

		if(pal == true)
			System.out.println("\'" + newStr + "\'" + " is a palindrome.");


		return testPerLine(c, newStr, newStart);					// recursively loop with newStart as the start value
	}



	public static boolean palTest(char[] test)
	{
		MyStack<Character> stack = new MyStack<>();


		int mid = 0;

		if(test.length % 2 == 1)
			mid = test.length / 2;						// java truncates integer division
		else
			mid = test.length / 2 - 1;


		for(int i = 0; i < mid; i++)
		{
			Character ch = new Character(test[i]);


			stack.push(ch);
		}



		char val;			  			 		// new char to store values in for comparing





		if(test.length % 2 == 1)						// if line has odd # of characters, then middle character must be accounted for
		{
			for(int i = mid; i < test.length; i++)
			{
				if(i == mid)						// if i == mid, then start popping the stack and testing values
				{
					char midVal = stack.pop().charValue();		// pop mid character just get it off the stack so we can start testing values
				}
				else							// for all values after mid, pop stack and compare value to test[j]
				{
					val = stack.pop().charValue();
					if(val != test[i])
						return false;				// false if they are not the same char
				}
				
			}


			return true;							// true if all characters matched their pre-mid counterparts


		}
		else									// if line has even # of characters, then there is no mid char to account for
		{		

			for(int j = mid + 1; j < test.length; j++)	// this loop pops values, and tests them against their pre-mid counterparts
			{
				val = stack.pop().charValue();
				if(val != test[j])
				{
					return false;			// returns false if any character doesn't match its pre-mid counterpart
				}
			}
			return true;	
		}

	} 


	public static final void main(String[] args) throws FileNotFoundException, IOException
	{
		File file = new File(args[0]);
												// creates file and reader to read in from palindromes.txt
		FileReader reader = new FileReader(file);




		char[] c = new char[1150];

		char[] newStr = new char[60];							// new char[] to fit one line; 60 should be big enough


		for(int i = 0; i < newStr.length; i++)
		{
			newStr[i] = 0;
		}



		System.out.println(reader.read(c) + "\n");					// prints out number of characters read

		reader.close();



		int filler = testPerLine(c, newStr, 0);						// filler should be 0; 0 indicates a successful test of the whole document
		

	}
}
