-- written.txt --
Contains solutions to written problems.




-- SpellChecker.java --
Checks spelling of inputted text document against an inputted dictionary. Inputs are given as command line inputs.

Can be compiled with any java compiler, and ran using a JVM.




-- words.txt --
Dictionary for use in SpellChecker.java.




-- filetospellcheck.txt --
Text file to be spell-checked by SpellChecker.




-- KBestCounter.java --
Keeps track of the k-largest number of elements in a given input sequence, stored in a PriorityQueue. 
Contains methods to check a value, and also to return a list of the current priority queue.

Can be compiled with any java compiler, and ran using a JVM.




-- TestKBest.java --
Given test file for testing the KBestCounter.

Can be compiled with any java compiler, and ran using a JVM.
