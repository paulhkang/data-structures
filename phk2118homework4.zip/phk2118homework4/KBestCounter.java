import java.util.*;

public class KBestCounter<T extends Comparable<? super T>> {

    PriorityQueue<T> heap;
    int k;

    public KBestCounter(int k) {
	heap = new PriorityQueue<T>(k); 
    }

    public void count(T x) {
	if(x.compareTo(heap.peek()) > 0)
	{
		heap.add(x);
	}
	else if(x.compareTo(heap.peek()) == 0)
	{
		if(heap.size() < k)
			heap.add(x);
	}
    }

    public List<T> kbest() {
	List<T> middle = new LinkedList<T>();
	List<T> output = new LinkedList<T>();

	PriorityQueue<T> copy = heap;

	while(copy.size() > 0)
	{
		middle.add(copy.poll());
	}

	while(!middle.isEmpty())
	{
		output.add(middle.get(middle.size() - 1));
	}

	return output;

    }

}
