// Implement a spelling checker by using a hash table. Output all misspelled words and the line numbers in which they occur.
// Also, for each misspelled word, list any words in the dictionary that are obtainable by applying any of the following rules:
// 	a. Add one character.
// 	b. Remove one character.
// 	c. Exchange adjacent characters.


// KNOWN BUG: Words that appear at the end of a line are marked as misspelled, even if they appear in the dictionary.
// These words hash to a different value than they should; there is most likely some hidden whitespace or 
// other hidden character in the string that causes the hash value to come out differently.

import java.io.*;
import java.util.*;

public class SpellChecker
{

	private static int linenum = 0;						// current line number 
	private static int startidx = 0;					// index of first character in next line
	private static boolean eof = false;					// end of file has been reached? 
	private static Hashtable<String, Integer> table = new Hashtable<>();

	// creates line subarray of full text document
	public static char[] lineFill(char[] wholeText)						
	{
		char[] line = new char[1001];

		int j = 0;

		for(int i = startidx; i < wholeText.length; i++)
		{
			if(j < line.length)
			{
				if(wholeText[i] != '\n' && wholeText[i] != '\r')
				{
//					System.out.println("copied!");
					line[j] = wholeText[i];
					j++;
				}
				else if(wholeText[i] == '\n')
				{
//					System.out.println("newline!");
					startidx = i + 1;
					break;
				}
			}
			else
			{
				break;
			}
		}


		// NOTE: file to be read must end with a newline character for this to work correctly!
		if(wholeText[startidx] == 0)		// if the wholeText array is empty at startidx, that is the end of the text file
		{
//			System.out.println("end of file!");
			eof = true;
		}

		linenum++;

		return line;
	}



	public static void checkSpelling(String[] array)
	{
		for(int i = 0; i < array.length; i++)
		{
			if(table.contains(array[i].hashCode()))
			{
				System.out.println("correct word length: " + array[i].length());
//				System.out.println("correct");
			}
			else
			{
				System.out.println("typo");
				System.out.println(array[i]);
				System.out.println(linenum);
//				System.out.println(array[i].hashCode());

				String copy = array[i];
				System.out.println("length: " + copy.length());

				for(int j = 0; j < copy.length(); j++)
				{
//					System.out.println(copy.charAt(j));
//					while(copy.charAt(j) 
				}


				System.out.println('\n');
			}
		}

	}


	public static final void main(String[] args) throws FileNotFoundException, IOException
	{
		File file0 = new File(args[0]);
		FileReader reader0 = new FileReader(file0);

		int dicsize = 1000000;
		char[] dictionaryUpper = new char[dicsize];

		int confirm = reader0.read(dictionaryUpper);
//		System.out.println(confirm);					// prints out number of characters read

		reader0.close();



		File file1 = new File(args[1]);
		FileReader reader1 = new FileReader(file1);

		int textsize = 36000;
		char[] textNotLower = new char[textsize];

		confirm = reader1.read(textNotLower);
//		System.out.println(confirm + "\n");

		reader1.close();




		char[] dictionary = new char[dicsize];
		for(int i = 0; i < dictionary.length; i++)
		{
			dictionary[i] = Character.toLowerCase(dictionaryUpper[i]);
		}








		char[] text = new char[textsize];				// new char[] that has been toLower'ed


		int j, k;
		k = 0;

		for(j = 0; j < textNotLower.length; j++)
		{
			if(textNotLower[j] != ',' && textNotLower[j] != '.' && textNotLower[j] != ':' && textNotLower[j] != '\ufeff')
			{
				text[k] = Character.toLowerCase(textNotLower[j]);
				k++;
			}
		}







		String dic = new String();
		String[] dicArr = new String[100000];

		dic = String.valueOf(dictionary);
		dicArr = dic.split("\\s+");

/*
		for(int i = 0; i < 10; i++)
		{
			System.out.println(dicArr[i]);
		}
*/





		String str = new String();
		String[] textArr = new String[10000];
		



		
		for(int i = 0; i < dicArr.length; i++)
		{
			table.put(dicArr[i], dicArr[i].hashCode());
		}

		Integer n = table.get(dicArr[2]);
		System.out.println(n);





		while(!eof)
		{
			char[] lineArr = lineFill(text); 
	
			str = String.valueOf(lineArr);
			textArr = str.split("\\s+");

//			System.out.println(linenum);
			
/*
			for(int i = 0; i < textArr.length; i++)
			{
				System.out.println(textArr[i]);
			}
*/

			checkSpelling(textArr);
		
//			System.out.println('\n');

		}


		for(int i = 0; i < textArr.length; i++)
		{
//			System.out.println(textArr[i]);
		}



	}
}
